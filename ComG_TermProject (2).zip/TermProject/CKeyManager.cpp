#include "stdafx.h"
#include "CKeyManager.h"

IMPLEMENT_SINGLETON(CKeyManager)

CKeyManager::CKeyManager()
{

}

CKeyManager::~CKeyManager()
{
}

void CKeyManager::UpdateKey()
{
	m_dwCurKey = 0;

	for (int i = 0; i < MAX_VKEY; ++i)
	{
		if (m_dwCurKey && !(GetAsyncKeyState(i) & 0x8000))
			m_dwCurKey = !m_dwCurKey;
		if (!m_dwCurKey && (GetAsyncKeyState(i) & 0x8000))
			m_dwCurKey = !m_dwCurKey;
	}

	if (GetAsyncKeyState(VK_UP) & 0x8000)		
		m_dwCurKey |= KEY_UP;
	if (GetAsyncKeyState(VK_DOWN) & 0x8000)
		m_dwCurKey |= KEY_DOWN;
	if (GetAsyncKeyState(VK_LEFT) & 0x8000)
		m_dwCurKey |= KEY_LEFT;
	if (GetAsyncKeyState(VK_RIGHT) & 0x8000)
		m_dwCurKey |= KEY_RIGHT;
	if (GetAsyncKeyState(VK_SPACE) & 0x8000)
		m_dwCurKey |= KEY_SPACE;
	if (GetAsyncKeyState(VK_ESCAPE) & 0x8000)
		m_dwCurKey |= KEY_ESCAPE;
	if (GetAsyncKeyState(0x41) & 0x8000)
		m_dwCurKey |= KEY_A;
	if (GetAsyncKeyState(0x46) & 0x8000)
		m_dwCurKey |= KEY_F;
	if (GetAsyncKeyState(0x32) & 0x8000)
		m_dwCurKey |= KEY_2;
	if (GetAsyncKeyState(0x33) & 0x8000)
		m_dwCurKey |= KEY_3;
	if (GetAsyncKeyState(0x34) & 0x8000)
		m_dwCurKey |= KEY_4;
	if (GetAsyncKeyState(0x35) & 0x8000)
		m_dwCurKey |= KEY_5;


}

bool CKeyManager::KeyDown(DWORD dwCurKey)
{
	// ���� ������ ���� ���� ������ �� true
	if (!(m_dwKeyDown & dwCurKey) && (m_dwCurKey & dwCurKey))
	{
		m_dwKeyDown |= dwCurKey;
		cout << "Key Down true " << dwCurKey << endl;
		return true;
	}

	// m_dwKeyDown�� ����
	// ���� ������ �ְ� ���� ������ �ʾ��� ��
	else if ((m_dwKeyDown & dwCurKey) && !(m_dwCurKey & dwCurKey))
	{
		m_dwKeyDown ^= dwCurKey;
		return false;
	}

	return false;
}

bool CKeyManager::KeyUp(DWORD dwCurKey)
{
	// ���� ������ �ְ� ���� ������ �ʾ��� �� true
	if ((m_dwKeyUp & dwCurKey) && !(m_dwCurKey & dwCurKey))
	{
		// m_dwKeyUp�� ����
		m_dwKeyUp ^= dwCurKey;
		return true;
	}

	// ���� ������ ���� ���� ������ �� 
	else if (!(m_dwKeyUp & dwCurKey) && (m_dwCurKey & dwCurKey))
	{
		m_dwKeyUp |= dwCurKey;
		return false;
	}

	return false;
}

bool CKeyManager::KeyPressing(DWORD dwCurKey)
{
	if (m_dwCurKey & dwCurKey)
	{
		//cout << "KeyDown true " << dwCurKey << endl;
		return true;
	}

	return false;
}


bool CKeyManager::KeyCombined(DWORD dwFirstKey, DWORD dwSecondKey)
{
	/*if (KeyDown(dwSecondKey) && KeyPressing(dwFirstKey))
		return true;*/
	if (KeyPressing(dwFirstKey))
	{
		if(KeyDown(dwSecondKey))
			return true;
	}
	return false;
}
