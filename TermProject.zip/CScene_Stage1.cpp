#include "CScene_Stage1.h"

CScene_Stage1::CScene_Stage1()
{
}

CScene_Stage1::~CScene_Stage1()
{
}

CScene* CScene_Stage1::Create()
{
	return nullptr;
}
