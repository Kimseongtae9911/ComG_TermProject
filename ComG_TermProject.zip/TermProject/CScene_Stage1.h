#pragma once
#include "CScene.h"

class CScene_Stage1 : public CScene
{
public:
	CScene_Stage1();
	~CScene_Stage1();

private:
	CScene* Create();
};

